# plex-aware-smart-room

small home setup that lets your room react to plex

no heavy frameworks  
no cloud nonsense  
just python + esp32

## pieces

- python monitor
  - watches plex via plexapi
  - calls your esp32 boxes over http

- esp32 light box
  - has relay for main lights
  - simple http server with /lights/dim and /lights/normal

- esp32 motion box
  - pir sensor
  - if you leave the room and plex is still playing, hits /api/pause-from-motion

- esp32 now-playing display
  - oled screen
  - polls /api/now-playing
  - shows title + progress

- esp32 fan box (optional)
  - ds18b20 temp sensor + relay
  - polls /api/is-playing
  - if hot and playing -> fan on

## quick start

1. edit `server/.env.example` and save as `.env`
2. `cd server`
3. `pip install -r requirements.txt`
4. `python monitor.py`
5. flash each esp32 sketch from `esp32/` after filling wifi + server ip

## notes

this repo is meant as a base for you to hack on
keep it ugly, keep it yours
